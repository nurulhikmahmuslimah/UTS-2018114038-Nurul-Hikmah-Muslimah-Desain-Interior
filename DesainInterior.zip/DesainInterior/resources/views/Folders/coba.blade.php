@extends('layouts.app')

@section('title', 'Cobaaaaa')

@section('content')
    Urutan ke - {{$ke}}
@endsection