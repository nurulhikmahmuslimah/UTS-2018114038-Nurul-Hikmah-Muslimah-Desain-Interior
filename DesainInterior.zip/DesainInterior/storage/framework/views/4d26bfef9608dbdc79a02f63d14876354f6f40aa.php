<?php $__env->startSection('title', 'Desain Interior'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <h3>Desain_Interior : <?php echo e($folder['Desain_Ruangan']); ?></h3>
        <h3>Tema_Ruangan : <?php echo e($folder['Tema_Ruangan']); ?></h3>
        <h3>Harga : <?php echo e($folder['Harga']); ?></h3>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DesainInterior\resources\views/folders/show.blade.php ENDPATH**/ ?>