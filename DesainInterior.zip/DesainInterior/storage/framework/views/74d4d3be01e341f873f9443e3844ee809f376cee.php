<?php $__env->startSection('title', 'Cobaaaaa'); ?>

<?php $__env->startSection('content'); ?>
    urutan ke - <?php echo e($ke); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DesainInterior\resources\views/Coba.blade.php ENDPATH**/ ?>