

<?php $__env->startSection('title', 'Folders'); ?>

<?php $__env->startSection('content'); ?>


<form action="/folders" method="post">
  <?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="exampleInputEmail1">Desain_Ruangan</label>
    <input type="text" class="form-control" id="exampleInputEmail1"  name="Desain_Ruangan" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Tema_Ruangan</label>
    <input type="text" class="form-control" name="Tema_Ruangan" id="exampleInputPassword1">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Harga</label>
    <input type="text" class="form-control" name="Harga" id="exampleInputPassword1">
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DesainInterior\resources\views/create.blade.php ENDPATH**/ ?>