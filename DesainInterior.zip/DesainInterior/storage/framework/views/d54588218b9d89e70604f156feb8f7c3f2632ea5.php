

<?php $__env->startSection('title', 'folders'); ?>

<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card" style="width: 18rem;">
  <div class="card-body">
    <a href="/folders/<?php echo e($folder['Id']); ?>" class="card-title"> <?php echo e($folder['Desain_Ruangan']); ?></a>
    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($folder['Tema_Ruangan']); ?></h6>
    <p class="card-text"><?php echo e($folder['Harga']); ?></p>

  <a href="/folders/<?php echo e($folder['id']); ?>/Edit" class="card-link btn-warning">Edit Tema</a>
<form action="/folders/<?php echo e($folder['id']); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
    <button class="card-link btn-danger">Delete Tema</a>
 </form>
  </div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div>
    <?php echo e($folders->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DesainInterior\resources\views/folders/index.blade.php ENDPATH**/ ?>