<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class folders extends Model
{
    use HasFactory;
    Protected $guarded = ['Desain_Ruangan'];
}
